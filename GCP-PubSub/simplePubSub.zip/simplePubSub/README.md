# mygcppubplanet

This repository is used in the following blog post: https://mydeveloperplanet.com/2019/05/22/spring-boot-and-gcp-cloud-pub-sub/
